<?php

return array(
	'CATEGORY_LIST' => array(
			array(
					'id' => 1,
					'class' => 'fa-mobile',
					'title' => 'Điện thoại'
			),
			array(
					'id' => 2,
					'class' => 'fa-laptop',
					'title' => 'Điện tử & Gia dụng'
			),
			array(
					'id' => 3,
					'class' => 'fa-car',
					'title' => 'Ô tô'
			),
			array(
					'id' => 4,
					'class' => 'fa-motorcycle',
					'title' => 'Xe máy & Xe đạp'
			),
			array(
					'id' => 5,
					'class' => 'fa-wheelchair',
					'title' => 'Nội thất'
			),
			array(
					'id' => 6,
					'class' => 'fa-paw',
					'title' => 'Vật nuôi'
			),
			array(
					'id' => 7,
					'class' => 'fa-book',
					'title' => 'Sách, Thể thao & Sở thích'
			),
			array(
					'id' => 8,
					'class' => 'fa-asterisk',
					'title' => 'Thời trang'
			),
			array(
					'id' => 9,
					'class' => 'fa-gamepad"',
					'title' => 'Vật dụng cho trẻ'
			),
			array(
					'id' => 10,
					'class' => 'fa-shield',
					'title' => 'Dịch vụ'
			),
			array(
					'id' => 11,
					'class' => 'fa-home',
					'title' => 'Nhà đất'
			),
			array(
					'id' => 12,
					'class' => 'fa-at',
					'title' => 'Khác'
			),
	)
);
