<?php
define('SESSION_LIFETIME', 45*60);
define('DS', DIRECTORY_SEPARATOR);

define('LOGIN_IDENTITY', 'loginUser');
define('LOGIN_IDENTITY_TIMELIFE', 'lifeTime');