<div class="main-banner banner text-center">
  <div class="container">    
		<h1>Bán hoặc quảng cáo   <span class="segment-heading">    trực tuyến bất kỳ đâu </span> với Banlai.vn</h1>
		<p>Trang thông tin rao vặt hàng đầu Việt Nam</p>
		<a href="post-ad.html">Đăng tin miễn phí</a>
  </div>
</div>