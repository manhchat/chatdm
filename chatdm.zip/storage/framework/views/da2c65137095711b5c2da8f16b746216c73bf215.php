<?php $__env->startSection('title', 'Page Title'); ?>
<?php $__env->startSection('content'); ?>
	<?php if(Session::has('message')): ?>
            <p class="alert"><?php echo e(Session::get('message')); ?></p>
        <?php endif; ?>
	<?php echo e(Form::open(array('url' => 'login/logon'))); ?>

		<?php echo Form::text('username', 'chadm', array(
			'class' => 'form-control'
		))?>
		<?php echo e(Form::password('password', array('placeholder'=>'Password', 'class'=>'form-control' ) )); ?>

		<?php echo Form::submit('Login', array('class' => 'btn btn-primary'));?>
	<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>