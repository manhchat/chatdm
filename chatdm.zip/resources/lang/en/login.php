<?php

return [
	'login_title' => 'Login',
	'login_forgot_password' => 'Forgot Password ?',
	'login_click_here' => 'Click Here',
	'login_your_email' => 'Your Email',
	'login_your_login' => 'Login',
	'login_your_chuacotk' => 'For New People',
	'login_your_content' => 'Having hands on experience in creating innovative designs,I do offer design solutions which harness.',
	'login_your_dky' => 'Register Now !',
	'login_your_password' => 'Your password',
	'login_please_input_email' => 'Please input your email.',
	'login_please_input_password' => 'Please input your password.',
	'login_format_email' => 'Email input invalid.',
	'login_max_email' => 'Email vượt quá ký tự cho phép là 100.',
	'login_incorrect' => 'Email hoặc mật khẩu không đúng.',
];
