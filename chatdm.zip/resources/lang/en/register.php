<?php

return [
	'register_title' => 'Create an account',
	'register_content' => 'Having hands on experience in creating innovative designs,I do offer design solutions which harness.',
	'register_info' => 'Personal Information',
	'register_email' => 'Email Address*',
	'register_pass' => 'Password*',
	'register_cpass' => 'Confirm Password*',
	'register_gobackto' => 'Go back to ',
	'register_home' => 'Home',
	'register_create' => 'Create',
];
