<?php
return [
		'register_title' => 'Đăng ký tài khoản',
		'register_content' => 'Website giúp bạn rao bán hiệu quả hơn, kiếm nhiều tòng hơn',
		'register_info' => 'Thông tin cá nhân',
		'register_email' => 'Địa chỉ email*',
		'register_pass' => 'Mật khẩu*',
		'register_cpass' => 'Nhập lại mật khẩu*',
		'register_gobackto' => 'Trở về ',
		'register_home' => 'Trang chủ',
		'register_create' => 'Tạo',
		
		
		
];