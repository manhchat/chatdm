<?php

return [
	'login_title' => 'Đăng nhập',
	'login_forgot_password' => 'Quên mật khẩu?',
	'login_click_here' => 'Click vào đây',
	'login_your_email' => 'Email của bạn',
	'login_your_login' => 'Đăng nhập',
	'login_your_chuacotk' => 'Chưa có tài khoản ?',
	'login_your_content' => 'Chúng tôi luôn tạo ra sự mới mẻ cùng những tính năng tuyệt vời cho website nhằm giúp các bạn bán hàng được hiệu quả hơn. Sẽ luôn là như vậy !',
	'login_your_dky' => 'Đăng ký ngay !',
	'login_your_password' => 'Mật khẩu của bạn',
	'login_please_input_email' => 'Hãy nhập địa chỉ email của bạn.',
	'login_please_input_password' => 'Hãy nhập mật khẩu của bạn.',
	'login_format_email' => 'Email không đúng định dạng.',
	'login_max_email' => 'Email vượt quá ký tự cho phép là 100.',
	'login_incorrect' => 'Email hoặc mật khẩu không đúng.',
];
