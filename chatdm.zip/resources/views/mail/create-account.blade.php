<h1>Hi, {{ $email }}!</h1>
 
<p>We'd like to personally welcome you to the Laravel 4 Authentication Application. Thank you for registering!</p>
