<!--footer section start-->
<footer class="diff">
	<p class="text-center"><?php echo trans('home.footer_copyright')?></p>
</footer>
<!--footer section end-->