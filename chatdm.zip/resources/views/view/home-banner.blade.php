<div class="main-banner banner text-center">
  <div class="container">    
		<h1><?php echo trans('home.ban_lai_sologan')?></h1>
		<p><?php echo trans('home.ban_lai_header_sologan')?></p>
		<a href="<?php echo url('dang-tin')?>"><?php echo trans('home.dang_tin_free')?></a>
  </div>
</div>