<?php

namespace App\Http\Controllers;

use App\Classes\PublicController;
use App;
use Session;
class CategoryController extends PublicController
{
    /**
     * Home action
     */
	
    public function index()
    {
    	return view('category/index');
    }
    /**
     * DucNV Starting
     * ChatDM comment
     */
}
