<?php

namespace App\Http\Controllers;

use App\Classes\PublicController;
use App;
use Session;
class PostController extends PublicController
{
    /**
     * Home action
     */
	
    public function index()
    {
    	return view('post/index');
    }
    /**
     * DucNV Starting
     * ChatDM comment
     */
}
