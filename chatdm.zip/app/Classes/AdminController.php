<?php

namespace App\Classes;

class AdminController extends CommonController
{
    public function __construct()
    {
    	
    }
}
