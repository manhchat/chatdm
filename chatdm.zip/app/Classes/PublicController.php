<?php

namespace App\Classes;

class PublicController extends CommonController
{
    public function __construct()
    {
    	parent::__construct();
    }
}
